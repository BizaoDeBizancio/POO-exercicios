package loteria;

public class NumeroAleatorio {
	public static int getAleatorio() {
		int numero = (int)(10*Math.random());
		return numero;
	}
}